import numpy as np

######################################################################################
#   The sigmoid function                                                             #
#     Input: z: can be a scalar, vector or a matrix                                  #
#     Output: sigz: sigmoid of scalar, vector or a matrix                            #
#     TODO: 1 line of code expected                                                  #
######################################################################################

def sigmoid (z):
    # Your code here
    # 1 line expected
    sig = 1/(1+np.exp(-z))
    # End your ode

    return sig
