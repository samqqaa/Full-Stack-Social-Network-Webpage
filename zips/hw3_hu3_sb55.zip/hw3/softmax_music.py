import random
import numpy as np
import matplotlib.pyplot as plt
import music_utils
from sklearn import cross_validation
import utils
from softmax import softmax_loss_naive, softmax_loss_vectorized
from softmax import SoftmaxClassifier
from one_vs_all import one_vs_allLogisticRegressor
from sklearn.metrics import confusion_matrix, classification_report


import time

# TODO: Get the music dataset (CEFS representation) [use code from Hw2]
# some global constants

MUSIC_DIR = "music/"
genres = ["blues","classical","country","disco","hiphop","jazz","metal","pop","reggae","rock"]

# select the CEPS or FFT representation

X,y = music_utils.read_ceps(genres,MUSIC_DIR)

# TODO: Split into train, validation and test sets 
X_train, X_test, y_train, y_test = cross_validation.train_test_split(X, y, test_size=0.2)
X_train, X_val, y_train, y_val = cross_validation.train_test_split(X_train, y_train, train_size=0.9)

# TODO: Use the validation set to tune hyperparameters for softmax classifier
# choose learning rate and regularization strength (use the code from softmax_hw.py)
best_val = -1
best_softmax = None
learning_rates = [1e-7, 5e-7, 1e-6, 5e-6]
regularization_strengths = [5e4, 1e5, 5e5, 1e8]

for alpha in learning_rates:
  for lmbd in regularization_strengths:
    smax = SoftmaxClassifier()
    smax.train(X_train,y_train,learning_rate=alpha,reg=lmbd,num_iters=4000,batch_size=400)
    accv = np.mean(y_val == smax.predict(X_val)).astype(float)
    acct = np.mean(y_train == smax.predict(X_train)).astype(float)
    print 'alpha %e lambda %e train accuracy: %f val accuracy: %f' % (alpha, lmbd, acct, accv)
    if accv > best_val:
      best_val = accv
      best_softmax = smax

print 'best softmax validation accuracy achieved during cross-validation: %f' % best_val

# TODO: Evaluate best softmax classifier on set aside test set (use the code from softmax_hw.py)

if best_softmax:
  y_test_pred = best_softmax.predict(X_test)
  test_accuracy = np.mean(y_test == y_test_pred)
  print confusion_matrix(y_test, y_test_pred)
  print classification_report(y_test, y_test_pred)
  print 'softmax on unseen data final test set accuracy: %f' % (test_accuracy, )

# TODO: Compare performance against OVA classifier of Homework 2 with the same
# train, validation and test sets (use sklearn's classifier evaluation metrics)
best_logreg = None
best_val_logreg = -1
for lmbd in regularization_strengths:
    ova_logreg = one_vs_allLogisticRegressor(np.arange(10))
    ova_logreg.train(X_train,y_train,lmbd,'l2')
    accv_l = np.mean(y_val == ova_logreg.predict(X_val))
    acct_l = np.mean(y_train == ova_logreg.predict(X_train))
    print 'alpha %e lambda %e train accuracy: %f val accuracy: %f' % (alpha, lmbd, acct_l, accv_l)
    if accv_l > best_val_logreg:
        best_val_logreg = accv_l
        best_logreg = ova_logreg

print 'best OVA validation accuracy achieved during cross-validation: %f' % best_val_logreg

if best_logreg:
    ypred = best_logreg.predict(X_test)
    ova_test_accuracy = np.mean(y_test == ypred)
    print confusion_matrix(y_test,ypred)
    print classification_report(y_test, ypred)
    print 'OVA on unseen data final test set accuracy: %f' % (np.mean((ypred==y_test)), )

