import random
import numpy as np
import matplotlib.pyplot as plt
import utils
from softmax import softmax_loss_naive, softmax_loss_vectorized
from softmax import SoftmaxClassifier
import time

# TODO: Get the music dataset (CEFS representation) [use code from Hw2]


# TODO: Split into train, validation and test sets 


# TODO: Use the validation set to tune hyperparameters for softmax classifier
# choose learning rate and regularization strength (use the code from softmax_hw.py)


# TODO: Evaluate best softmax classifier on set aside test set (use the code from softmax_hw.py)


# TODO: Compare performance against OVA classifier of Homework 2 with the same
# train, validation and test sets (use sklearn's classifier evaluation metrics)
